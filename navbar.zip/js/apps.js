var navShow=document.getElementById('nav-show');
var navIcon=document.getElementById('nav-icon');
var faBars=document.querySelector('.fa-bars');
var times=document.querySelector('.fa-times');
faBars.addEventListener('click',function(){
    navShow.classList.add('active');
    faBars.style.display="none";
    times.style.display="block";
})
times.addEventListener('click',function(){
    navShow.classList.remove('active');
    faBars.style.display="block";
    times.style.display="none";
})